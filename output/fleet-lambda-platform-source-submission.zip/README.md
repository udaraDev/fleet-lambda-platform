# Fleet Lambda Platform

A local, end-to-end big-data demonstration for ride-hailing operations. Simulated
vehicle events provide near-real-time fleet and zone insights; daily expense
files are reconciled with archived trips to produce vehicle profitability.
The system uses a **Lambda architecture**: a speed path for immediate answers
and a batch path for authoritative historical reports.

This is a classroom deployment on one Docker host, not a production service.
One simulated day lasts five real minutes; monetary values are integer LKR
cents. See the [delivered scope](docs/FINAL_SCOPE.md) for limitations.

## Architecture

Kafka feeds independent speed and raw Spark consumers:

```mermaid
flowchart LR
    Telemetry["Telemetry simulator"] --> Kafka[("Kafka: trip-events")]

    Kafka --> Speed["Spark speed stream<br/>live state, alerts, 1-minute windows"]
    Kafka --> Raw["Spark raw stream"]
    Raw --> Archive[("MinIO: partitioned Parquet<br/>and integrity manifests")]

    Expenses["Daily expense simulator"] --> Landing[("Shared volume: expense CSV")]
    Landing --> Batch["Spark batch reconciliation"]
    Airflow["Airflow: daily and quality workflows"] -.->|orchestrates| Batch
    Airflow -.->|checks| Landing
    Archive --> Batch

    Speed --> Postgres[("PostgreSQL: serving tables")]
    Batch --> Postgres
    Batch --> Exports[("Shared volume: JSON, CSV,<br/>HTML and Parquet reports")]
    Postgres --> API["FastAPI and business page"]
    Prometheus["Prometheus metrics and alerts"] -.->|scrapes| API
    Grafana["Grafana dashboards"] -.->|queries| Prometheus
```

![Implementation architecture](docs/img/architecture.png)

Solid arrows show data movement; dashed arrows show orchestration or
monitoring. The quality workflow also checks archive and report integrity.

Kafka's three-partition topic buffers and replays telemetry. Two independent
Spark Structured Streaming consumers read it: the speed consumer updates
PostgreSQL, while the raw consumer commits immutable Parquet to MinIO. Airflow
orchestrates Spark reconciliation of that archive with the daily expense CSV.
This separation lets a corrected cost file restate historical results without
rewriting source events. PostgreSQL serves live and daily queries; MinIO retains
the event history. The batch path may briefly lag the speed path. The
[architecture decisions](docs/adr/) explain the technology choices.

## Start locally

You need Docker Desktop with Linux containers, Docker Compose v2.20+ (with
BuildKit enabled), Python 3.11, PowerShell 7 for the commands below,
at least 8 GB available to Docker, and
internet access for the first image build. From the repository root:

```powershell
py -3.11 -m scripts.bootstrap_env
docker compose up --build -d
docker compose ps -a
```

The bootstrap command creates a git-ignored `.env` with random local secrets;
it will not overwrite one. Keep this file private. Initialization containers
exit after setup; that is expected. On a fresh dataset, the first expense file
arrives after about five minutes; Airflow can then produce the first daily
report. Builds may take longer on a cold machine.

The web interfaces are available only on the computer running this Docker
stack; they are not public links from GitHub. Airflow, Grafana, and MinIO
credentials are in `.env`. Ports bind to `127.0.0.1`; Kafka and PostgreSQL are
not exposed to the host. A running page does not guarantee fresh data, so
check pipeline and report health before a demo.

To stop the platform without removing its named volumes, run
`docker compose down`. Do **not** use `--volumes` unless you intend to erase the
demonstration dataset. See [advanced operations](docs/OPERATIONS.md) for logs,
migration, recovery, and benchmark procedures.

## Verify

Install the host-side test dependencies and run the unit/API/archive suite:

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\python -m pip install -r requirements-dev.txt
.\.venv\Scripts\python -m unittest discover -s tests -q
docker compose config --quiet
```

The last recorded host run completed 66 tests: 65 passed and one expected skip.
The Spark/Python parity test needs PySpark in the application image. Run that test
and the isolated reconciliation checks there:

```powershell
docker compose run --rm --no-deps tools python -m unittest tests.test_completion.SparkPythonParityTests -v
docker compose run --rm tools python -m scripts.verify_reconciliation
```

Check the running platform and a clean set of disposable volumes with:

```powershell
.\.venv\Scripts\python -m scripts.verify_running --wait-seconds 480
.\.venv\Scripts\python -m scripts.verify_clean_install
```

The [saved verification evidence](output/evidence/final-verification.json)
records passing live, isolated, and fresh-volume checks. The clean-install
check used new volumes on the same Docker host; a second-computer installation
has not been demonstrated. The short 10/100/500 events-per-second runs in the
[benchmark evidence](output/evidence/performance-benchmark.json) do not establish
sustained production capacity.

## Interpret results safely

Live state is indicative; daily profitability is recomputed from committed
archive data. Missing expenses or telemetry and conflicting event identities
produce explicit unknown/incomplete outcomes, not invented profit or loss.
Invalid inputs are quarantined. Report exports are published as JSON, CSV,
HTML, and Parquet with a digest manifest. This platform does not claim
end-to-end exactly-once delivery.

The deployment uses one Kafka broker, local Spark workers, single-node MinIO,
and one PostgreSQL instance. It has no external TLS, API authentication,
replication, or disaster-recovery automation. Do not expose it publicly.

## Submission and team

- [Source code ZIP](output/fleet-lambda-platform-source-submission.zip) - current source,
  configuration, tests, diagrams, documentation and verification evidence.
- [Final report PDF](output/pdf/fleet-lambda-platform-report.pdf) is included in
  the repository and submitted separately. The demo MP4 is submitted separately.
  Neither generated media file is included in the source code ZIP.
- [Contribution statement](docs/CONTRIBUTION_STATEMENT.md)
