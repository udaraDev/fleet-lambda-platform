"""Bounded bulk serving writes in the same transaction as the commit ledger.

No connection or query per event. Retain one ordered state fold per bounded
micro-batch; scaling past this cap requires partition staging plus a final merge.
"""

import hashlib
import json
from collections import defaultdict

from psycopg2.extras import Json, execute_values

from common.domain import parse_timestamp
from common.events import EVENT_FIELDS
from common.settings import DEAD_LETTER_TOPIC


def dead_letter_send(producer, raw_value: str, error_reason: str,
                     partition: int = None, offset: int = None,
                     batch_id: int = None, cur=None):
    """Publish a malformed event to the dead-letter Kafka topic and optionally
    record it in stream_dead_letters for SQL diagnostics.

    `producer` must be a kafka-python KafkaProducer (or None for unit tests).
    `cur` is an open psycopg2 cursor; pass None to skip the DB mirror.
    """
    if producer is not None:
        try:
            producer.send(DEAD_LETTER_TOPIC,
                          value=json.dumps({"raw": raw_value, "error": error_reason,
                                            "partition": partition, "offset": offset}).encode())
        except Exception:
            pass  # Never let dead-letter publishing crash the main pipeline.
    if cur is not None:
        try:
            cur.execute("""
                INSERT INTO stream_dead_letters
                    (batch_id, kafka_partition, kafka_offset, raw_value, error_reason)
                VALUES (%s, %s, %s, %s, %s)
            """, (batch_id, partition, offset, raw_value, error_reason))
        except Exception:
            pass

def fingerprint(item):
    canonical = {k: item[k] for k in EVENT_FIELDS}
    canonical["event_ts"] = parse_timestamp(canonical["event_ts"]).isoformat()
    return hashlib.sha256(json.dumps(canonical, sort_keys=True).encode()).hexdigest()


def _reconcile_metric_events(cur, accepted, conflicting_ids, bad_trips, conflict_payloads):
    """Maintain retractable inputs for windows that contain a conflict.

    Spark remains the normal window calculator.  This compact contribution table
    lets the authoritative serving transaction retract a previously accepted
    event and recompute only affected minute/zone keys.  Corrected rows are
    protected from later, non-retracting Spark update-mode output.
    """
    affected = set()
    if conflicting_ids or bad_trips:
        cur.execute("""SELECT window_start,zone FROM rt_zone_metric_events
            WHERE event_id=ANY(%s) OR trip_id=ANY(%s)""",
            (list(conflicting_ids), list(bad_trips)))
        affected.update(cur.fetchall())
        cur.execute("""DELETE FROM rt_zone_metric_events
            WHERE event_id=ANY(%s) OR trip_id=ANY(%s)""",
            (list(conflicting_ids), list(bad_trips)))
    for payload in conflict_payloads:
        if payload.get("event_ts") and payload.get("zone"):
            affected.add((parse_timestamp(payload["event_ts"]).replace(second=0, microsecond=0), payload["zone"]))
    if accepted:
        execute_values(cur, """INSERT INTO rt_zone_metric_events
            (event_id,trip_id,fingerprint,window_start,zone,vehicle_id,status,trip_completed,fare_cents)
            VALUES %s ON CONFLICT(event_id) DO NOTHING""", [
            (e["event_id"], e.get("trip_id"), fingerprint(e),
             parse_timestamp(e["event_ts"]).replace(second=0, microsecond=0),
             e["zone"], e["vehicle_id"], e["status"], e["trip_completed"], e["fare_cents"])
            for e in accepted])
    for window_start, zone in affected:
        cur.execute("""INSERT INTO rt_zone_metrics
            (window_start,zone,reporting_vehicles,active_vehicles,idle_ratio,trips,earnings_cents,authoritative_corrected)
            SELECT %s,%s,
                count(DISTINCT vehicle_id),
                count(DISTINCT vehicle_id) FILTER (WHERE status <> 'idle'),
                count(DISTINCT vehicle_id) FILTER (WHERE status = 'idle')::numeric /
                    NULLIF(count(DISTINCT vehicle_id),0),
                count(*) FILTER (WHERE trip_completed),
                COALESCE(sum(fare_cents) FILTER (WHERE trip_completed),0),true
            FROM rt_zone_metric_events WHERE window_start=%s AND zone=%s
            ON CONFLICT(window_start,zone) DO UPDATE SET
                reporting_vehicles=EXCLUDED.reporting_vehicles,
                active_vehicles=EXCLUDED.active_vehicles,idle_ratio=EXCLUDED.idle_ratio,
                trips=EXCLUDED.trips,earnings_cents=EXCLUDED.earnings_cents,
                authoritative_corrected=true,updated_at=now()""",
            (window_start, zone, window_start, zone))


def bulk_serve(cur, events, batch_id):
    if not events:
        return 0
    if len(events) > 2500:
        raise ValueError("Serving batch exceeds bounded driver cap")
    ids = list({e["event_id"] for e in events})
    trip_ids = list({e["trip_id"] for e in events if e["trip_id"]})
    cur.execute("SELECT event_id,fingerprint,event_ts,vehicle_id,trip_id FROM stream_event_keys WHERE event_id=ANY(%s)", (ids,))
    prior_events = {r[0]: r[1:] for r in cur.fetchall()}
    known = {key: value[0] for key, value in prior_events.items()}
    trip_ids = list(set(trip_ids) | {v[3] for v in prior_events.values() if v[3]})
    cur.execute("SELECT trip_id,vehicle_id,fare_cents,completed_at,zone FROM completed_trips WHERE trip_id=ANY(%s)", (trip_ids,))
    old_trips = {r[0]: r[1:] for r in cur.fetchall()}
    cur.execute("SELECT event_id,payload FROM stream_conflicts WHERE event_id=ANY(%s) OR payload->>'trip_id'=ANY(%s)", (ids, trip_ids))
    blocked_events, blocked_trips = set(), set()
    for event_id, payload in cur.fetchall():
        blocked_events.add(event_id)
        if payload.get("trip_id"):
            blocked_trips.add(payload["trip_id"])
    by_id = defaultdict(list)
    for event in events:
        by_id[event["event_id"]].append(event)
    conflicting_ids = {key for key, copies in by_id.items()
                       if len({fingerprint(e) for e in copies} | ({known[key]} if key in known else set())) > 1}
    conflicting_ids |= blocked_events
    signatures = defaultdict(set)
    for event in events:
        if event["trip_completed"]:
            signatures[event["trip_id"]].add((event["vehicle_id"], event["fare_cents"],
                                             parse_timestamp(event["event_ts"]), event["zone"]))
    bad_trips = {trip for trip, values in signatures.items()
                if len(values | ({old_trips[trip]} if trip in old_trips else set())) > 1}
    bad_trips |= blocked_trips | {e["trip_id"] for e in events if e["event_id"] in conflicting_ids and e["trip_id"]}
    bad_trips |= {prior_events[key][3] for key in conflicting_ids & prior_events.keys() if prior_events[key][3]}
    rejected, accepted = [], []
    for key in conflicting_ids & prior_events.keys():
        _, ts, vehicle, trip = prior_events[key]
        rejected.append((batch_id, key, ts.date(), "prior_event_conflict",
                         Json({"vehicle_id": vehicle, "trip_id": trip})))
    for event_id, copies in by_id.items():
        item = copies[0]
        if event_id in conflicting_ids or item["trip_id"] in bad_trips:
            # Preserve every distinct conflict payload; raw archive retains all copies.
            for index, item in enumerate(copies):
                rejected.append((batch_id, event_id, parse_timestamp(item["event_ts"]).date(),
                                 f"conflicting_event_or_trip_{index}", Json(item)))
        elif event_id not in known:
            accepted.append(item)
    for trip in bad_trips & old_trips.keys():
        vehicle, fare, ts, zone = old_trips[trip]
        rejected.append((batch_id, "prior:" + trip, ts.date(), "prior_trip_conflict",
                         Json({"trip_id": trip, "vehicle_id": vehicle, "fare_cents": fare})))
    if rejected:
        execute_values(cur, """INSERT INTO stream_conflicts(batch_id,event_id,dt,reason,payload)
                       VALUES %s ON CONFLICT DO NOTHING""", rejected)
    if bad_trips:
        cur.execute("DELETE FROM completed_trips WHERE trip_id=ANY(%s)", (list(bad_trips),))
    if conflicting_ids or bad_trips:
        # Unknown is safer than continuing to display a discredited observation.
        # A new accepted observation reintroduces the vehicle; never replay a bad state.
        cur.execute("""DELETE FROM rt_vehicle_state WHERE event_id=ANY(%s) OR event_id IN
            (SELECT event_id FROM stream_event_keys WHERE trip_id=ANY(%s))""",
            (list(conflicting_ids), list(bad_trips)))
    _reconcile_metric_events(cur, accepted, conflicting_ids, bad_trips,
                             [item for copies in by_id.values() for item in copies
                              if item["event_id"] in conflicting_ids or item.get("trip_id") in bad_trips])
    if not accepted:
        return len(rejected)
    cur.execute("""SELECT vehicle_id,zone,status,idle_since,event_ts,event_id,trace_id
                   FROM rt_vehicle_state WHERE vehicle_id=ANY(%s)""", (list({e["vehicle_id"] for e in accepted}),))
    states = {r[0]: r for r in cur.fetchall()}
    changed, trips = {}, {}
    for item in sorted(accepted, key=lambda e: (parse_timestamp(e["event_ts"]), e["event_id"])):
        vehicle, ts = item["vehicle_id"], parse_timestamp(item["event_ts"])
        old = states.get(vehicle)
        if old is None or (ts, item["event_id"]) > (old[4], old[5]):
            idle = (old[3] if old and old[2] == "idle" else ts) if item["status"] == "idle" else None
            states[vehicle] = (vehicle, item["zone"], item["status"], idle, ts, item["event_id"], item["trace_id"])
            changed[vehicle] = states[vehicle]
        if item["trip_completed"]:
            trips[item["trip_id"]] = (item["trip_id"], vehicle, item["zone"], item["fare_cents"], ts,
                                      item["time_of_day_bucket"], item["trace_id"])
    if changed:
        execute_values(cur, """INSERT INTO rt_vehicle_state
            (vehicle_id,zone,status,idle_since,event_ts,event_id,trace_id) VALUES %s
            ON CONFLICT(vehicle_id) DO UPDATE SET zone=EXCLUDED.zone,status=EXCLUDED.status,
            idle_since=EXCLUDED.idle_since,event_ts=EXCLUDED.event_ts,event_id=EXCLUDED.event_id,
            trace_id=EXCLUDED.trace_id""", list(changed.values()))
    if trips:
        execute_values(cur, """INSERT INTO completed_trips
            (trip_id,vehicle_id,zone,fare_cents,completed_at,time_of_day_bucket,trace_id)
            VALUES %s ON CONFLICT DO NOTHING""", list(trips.values()))
    execute_values(cur, """INSERT INTO stream_event_keys
        (event_id,fingerprint,event_ts,vehicle_id,trip_id,batch_id) VALUES %s ON CONFLICT DO NOTHING""",
        [(e["event_id"], fingerprint(e), e["event_ts"], e["vehicle_id"], e["trip_id"], batch_id) for e in accepted])

    # --- rt_alerts: raise/resolve idle-threshold alerts ---
    from common.settings import IDLE_ALERT_MINUTES
    if changed or accepted:
        # Check current idle state for all vehicles that changed in this batch
        vehicles_to_check = list({v for v in changed} | {e["vehicle_id"] for e in accepted})
        if vehicles_to_check:
            cur.execute("""SELECT vehicle_id, idle_since FROM rt_vehicle_state
                           WHERE vehicle_id = ANY(%s)""", (vehicles_to_check,))
            idle_states = {r[0]: r[1] for r in cur.fetchall()}
            cur.execute("""SELECT vehicle_id, alert_id FROM rt_alerts
                           WHERE vehicle_id = ANY(%s) AND resolved_at IS NULL
                           AND alert_type = 'idle_threshold'""", (vehicles_to_check,))
            open_alerts = {r[0]: r[1] for r in cur.fetchall()}
            if accepted:
                max_ts = max(parse_timestamp(e["event_ts"]) for e in accepted)
                now_utc = max_ts
            else:
                from datetime import datetime as _dt, timezone as _tz
                now_utc = _dt.now(_tz.utc)
            for vid in vehicles_to_check:
                idle_since = idle_states.get(vid)
                if idle_since and (now_utc - idle_since).total_seconds() >= IDLE_ALERT_MINUTES * 60:
                    if vid not in open_alerts:
                        idle_min = (now_utc - idle_since).total_seconds() / 60
                        cur.execute("""INSERT INTO rt_alerts
                            (vehicle_id, alert_type, severity, idle_minutes, payload)
                            VALUES (%s, 'idle_threshold', 'warning', %s, %s)""",
                            (vid, idle_min, Json({"idle_since": idle_since.isoformat()})))
                elif vid in open_alerts:
                    # Vehicle is no longer idle — resolve the open alert
                    cur.execute("""UPDATE rt_alerts SET resolved_at = now()
                                   WHERE alert_id = %s""", (open_alerts[vid],))

    return len(rejected)
